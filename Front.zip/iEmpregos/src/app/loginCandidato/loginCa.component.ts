import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginCa',
  templateUrl: './loginCa.component.html',
  styleUrls: ['./loginCa.component.css']
})
export class LoginCaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

export class Vaga {
    id: number;
    idEmpresa: number;
    nome: string;
    descricao: string;
    salario: number;
}
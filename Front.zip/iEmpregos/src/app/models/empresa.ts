export class Empresa {
    id: number;
    razaoSocial: string;
    nomeFantasia: string;
    cnpj: string;
    email: string;
    senha: string;
}
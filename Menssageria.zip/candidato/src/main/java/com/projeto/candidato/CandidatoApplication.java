package com.projeto.candidato;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;




@EnableRabbit
@SpringBootApplication
public class CandidatoApplication {
	
	@Value("${fila.cadastro.nome}")
    private String nomeDaFila;
	
	public static void main(String[] args) {
		SpringApplication.run(CandidatoApplication.class, args);
	}
	
	@Bean
    public Queue fila() {
        return new Queue(nomeDaFila, true);
    }

}

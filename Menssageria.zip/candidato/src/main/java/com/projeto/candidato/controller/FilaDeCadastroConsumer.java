package com.projeto.candidato.controller;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;
@Component
public class FilaDeCadastroConsumer {
	@RabbitListener(queues = {"${fila.cadastro.nome}"})
    public void receive(@Payload String pedido) {
       System.out.println("Cadastro feito: " + pedido);
    }
}

package com.projeto.candidato.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotBlank;

@Entity
public class Candidato {

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	private long id;

	private String nome;

	private String endereco;
	private String data_nascimento;

	private String telefone;

	private String email;

	private String cpf;
	private String senha;

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public Candidato(Long Id, String nome, String endereco,
			String data_nascimento, String telefone, String email, String cpf) {
		this.id = id;
		this.nome = nome;
		this.endereco = endereco;
		this.data_nascimento = data_nascimento;
		this.telefone = telefone;
		this.email = email;
		this.cpf = cpf;
		this.senha = senha;
	}

	public Candidato() {
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereço(String endereco) {
		this.endereco = endereco;
	}

	public String getData_nascimento() {
		return data_nascimento;
	}

	public void setData_nascimento(String data_nascimento) {
		this.data_nascimento = data_nascimento;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

}

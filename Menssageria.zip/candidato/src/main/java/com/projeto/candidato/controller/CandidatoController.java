package com.projeto.candidato.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.projeto.candidato.models.Candidato;
import com.projeto.candidato.repository.CandidatoRepository;


//@Api(value = "API REST Eventos")
@RestController
@RequestMapping("/api")
//@CrossOrigin(origins = "http://localhost:4200")
public class CandidatoController {

	@Autowired
	private CandidatoRepository er;
	int cont;
	boolean validador = false;

	// listar
	@ApiOperation(value = "Retorna uma lista de Candidato")
	@GetMapping("/candidatos")
	public List<Candidato> getAllCandidatos() {
		return er.findAll();
	}

	// listar por id
	@ApiOperation(value = "Retorna uma lista de Candidato por id")
	@GetMapping("/candidato/{Id}")
	public Candidato getCandidatoById(@PathVariable(value = "Id") Long Id) {

		return er.findOne(Id);
	}

	// atualizar por id
	@ApiOperation(value = "Atualiza um Candidato por id")
	@PutMapping("/candidato/{Id}")
	public Candidato updateCandidato(@PathVariable(value = "Id") Long Id,
			@Valid @RequestBody Candidato candidatoDetails) {

		Candidato candidato = er.findOne(Id);

		candidato.setNome(candidatoDetails.getNome());
		candidato.setData_nascimento(candidatoDetails.getData_nascimento());
		candidato.setEmail(candidatoDetails.getEmail());
		candidato.setEndereço(candidatoDetails.getEndereco());
		candidato.setTelefone(candidatoDetails.getTelefone());

		Candidato updatedcandidato = er.save(candidato);
		return updatedcandidato;
	}

	// cadastrar
	@ApiOperation(value = "Cadastra um candidato")
	@PostMapping("/candidato/post")
	public Candidato cadastracandidato(@RequestBody @Valid Candidato candidato) {
		er.save(candidato);
		validador = true;
		return candidato;
	}

	

	// deletar

	@ApiOperation(value = "Deleta um candidato")
	@DeleteMapping("/candidato/{Id}")
	public void deleteCandidato(@PathVariable(value = "Id") long Id) {
		er.delete(Id);
	}

}

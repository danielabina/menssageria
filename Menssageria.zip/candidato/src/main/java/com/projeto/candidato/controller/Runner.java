package com.projeto.candidato.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.projeto.candidato.Cors;


@Component
public class Runner implements CommandLineRunner {

    @Autowired
    private FilaDeCadastroSender sender;
    Cors controller = new Cors();

    public void run(String... args) throws Exception {
    	if (veri(0) == true){
        sender.send("Teste de envio do cadastro por fila no RabbitMQ!");
    	}
        System.out.println("O cadastro esta na fila...");
    }


	public static  boolean veri(int test) {
		if(test == 1)
		{
			return false;
		}
		return true;
	}
}
